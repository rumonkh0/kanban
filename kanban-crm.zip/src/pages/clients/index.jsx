import React from "react";
import { Outlet } from "react-router";

function index() {
  return <Outlet />;
}

export default index;
