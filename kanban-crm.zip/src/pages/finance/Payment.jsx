import { useState } from "react";
import Icon from "@/components/Icon";
import Modal from "@/components/Modal";
import PaymentDetailsModal from "@/components/PaymentDetailsModal";
import { Td, Th } from "@/components/Component";
import DropdownMenu from "@/components/DropdownMenu";
import { Link } from "react-router";
import {
  Dropdown,
  FilterDropdown,
  ImageName,
} from "../../components/Component";
import {
  useDeletePaidFrom,
  usePaidFroms,
  useUpdatePaidFrom,
} from "../../hooks/useFinance";

function Payment({ from }) {
  const [PaymentsModal, setPaymentModal] = useState(false);
  const [activeMenu, setActiveMenu] = useState(null);
  const [currentId, setCurrentId] = useState(null);
  const [filters, setFilters] = useState({
    status: "",
    match: "",
    client: "",
  });

  const filterConfigs = [
    {
      key: "status",
      label: "Status",
      options: ["Active", "Inactive", "Pending"],
    },
    {
      key: "match",
      label: "Select Match",
      options: ["Match 1", "Match 2", "Match 3"],
    },
    {
      key: "client",
      label: "Select Client",
      options: ["Client 1", "Client 2", "Client 3"],
    },
  ];
  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };
  const handleMenuClick = (index, e) => {
    e.preventDefault();
    setActiveMenu(activeMenu === index ? null : index);
  };
  const deletePaidFrom = useDeletePaidFrom();
  const handleDelete = (id) => {
    deletePaidFrom.mutate(id, {
      onSuccess: () => {
        console.log(`Deleted payment with id: ${id}`);
      },
      onError: (error) => {
        console.error("Failed to delete:", error);
      },
    });
  };

  const { data: financeData, isLoading, isError } = usePaidFroms(filters);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (isError) {
    return <div>Error loading clients</div>;
  }
  const payments = Array.isArray(financeData) || [
    {
      id: 1,
      project: "Wellness App Redesign",
      paidFrom: "Client A",
      haveToPay: 1000,
      paymentDate: "2025-09-01",
      amountPaid: 600,
      amountOwed: 400,
      paymentMethod: "Bank Transfer",
      status: "Owed",
    },
    {
      id: 2,
      project: "E-commerce Platform",
      paidFrom: "Client B",
      haveToPay: 2000,
      paymentDate: "2025-09-05",
      amountPaid: 2000,
      amountOwed: 0,
      paymentMethod: "Credit Card",
      status: "Paid",
    },
    {
      id: 3,
      project: "Mobile Game Launch",
      paidFrom: "Client C",
      haveToPay: 1500,
      paymentDate: "2025-09-07",
      amountPaid: 1000,
      amountOwed: 500,
      paymentMethod: "PayPal",
      status: "Owed",
    },
    {
      id: 4,
      project: "Marketing Website",
      paidFrom: "Client D",
      haveToPay: 800,
      paymentDate: "2025-09-10",
      amountPaid: 800,
      amountOwed: 0,
      paymentMethod: "Bank Transfer",
      status: "Paid",
    },
    {
      id: 5,
      project: "Internal Dashboard",
      paidFrom: "Client E",
      haveToPay: 1200,
      paymentDate: "2025-09-12",
      amountPaid: 600,
      amountOwed: 600,
      paymentMethod: "Credit Card",
      status: "Owed",
    },
  ];

  return (
    <>
      <div className=" h-10 flex justify-between mb-4">
        <div className="flex gap-4">
          <Link
            to={`/${from}/paid-by`}
            className="px-4 typo-cta bg-brand rounded-sm flex items-center gap-1"
          >
            <div className="w-6 h-6 flex justify-center items-center">
              <Icon name="plus" size={15} />
            </div>
            Paid From
          </Link>
        </div>
        <div className="flex py-1 gap-4">
          {filterConfigs.map(({ key, label, options }) => (
            <FilterDropdown
              key={key}
              label={label}
              options={options}
              value={filters[key]}
              onSelect={(value) => handleFilterChange(key, value)}
              className="h-8"
            />
          ))}
        </div>
      </div>
      <div className="overflow-x-auto p-2 pb-1.5 border-2 border-divider rounded-lg bg-surface2 shadow-sm">
        <table className="min-w-full border-separate border-spacing-y-1 border-spacing-x-0">
          <thead className="table-header-group after:content-[''] after:block after:h-1">
            <tr className="text-left">
              <Th title="Project" />
              <Th title="Paid From" />
              <Th title="Have To Paid" />
              <Th title="Payment Date" />
              <Th title="Amount Pain" />
              <Th title="Amount Owed" />
              <Th title="Payment Method" />
              <Th title="Status" />
              <Th title="Action" />
            </tr>
          </thead>
          <tbody>
            {payments.map((payment, index) => (
              <tr
                key={payment.id}
                className="h-17 px-4 shadow-sm hover:[&_td]:bg-divider/80 transition-colors"
              >
                {/* Project Name */}
                <Td className="first:rounded-l-[4px]">{payment.project}</Td>

                {/* Paid From (Client) */}
                <Td>
                  <ImageName
                    username={payment.paidFrom}
                    designation={payment.paidFrom}
                    image="/images/profile.png"
                  />
                </Td>

                {/* Have To Pay */}
                <Td>${payment.haveToPay}</Td>

                {/* Payment Date */}
                <Td>{payment.paymentDate}</Td>

                {/* Amount Paid */}
                <Td className="text-success">${payment.amountPaid}</Td>

                {/* Amount Owed */}
                <Td className="text-brand">${payment.amountOwed}</Td>

                {/* Payment Method */}
                <Td>{payment.paymentMethod}</Td>

                {/* Status */}
                <StatusCell payment={payment} />

                {/* Action Menu */}
                <Td className="last:rounded-r-[4px] relative">
                  <button
                    onClick={(e) => handleMenuClick(index, e)}
                    className="p-2 rounded-sm border-2 border-text2 cursor-pointer hover:bg-surface2/60"
                  >
                    <Icon name="menu" size={20} />
                  </button>
                  <DropdownMenu
                    isOpen={activeMenu === index}
                    onClose={() => setActiveMenu(null)}
                    menuItems={[
                      {
                        label: "View",
                        onClick: () => {
                          setCurrentId(payment.id);
                          setPaymentModal(true);
                        },
                      },
                      {
                        label: "Edit",
                        href: `/${from}/paid-by/${payment.id}/edit`,
                      },
                      {
                        label: "Delete",
                        onClick: () => handleDelete(payment.id),
                      },
                    ]}
                  />
                </Td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Modal isOpen={PaymentsModal} onClose={() => setPaymentModal(false)}>
        <PaymentDetailsModal
          onClose={() => setPaymentModal(false)}
          id={currentId}
        />
      </Modal>
    </>
  );
}

const StatusCell = ({ payment }) => {
  const updateStatusMutation = useUpdatePaidFrom(payment.id);

  return (
    <Td>
      <div className="relative">
        {/* Colored dot */}
        <div
          className={`w-2 h-2 rounded-full absolute left-4 top-1/2 -translate-y-1/2 z-10 ${
            payment.status === "Paid"
              ? "bg-success"
              : payment.status === "Unpaid"
              ? "bg-brand"
              : payment.status === "Owed"
              ? "bg-[#A88AED]"
              : ""
          }`}
        ></div>

        {/* Dropdown */}
        <Dropdown
          options={["Owed", "Paid", "Unpaid"]}
          value={payment.status}
          onChange={(val) => updateStatusMutation.mutate({ status: val })}
          className="pl-8 h-10 bg-divider w-30 rounded-sm border-text2"
        />
      </div>
    </Td>
  );
};

export default Payment;
