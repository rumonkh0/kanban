import { Outlet } from "react-router";

function index() {
  return <Outlet />;
}

export default index;
