import TasksManage from "@/components/Task";

function Tasks() {
  return <TasksManage />;
}

export default Tasks;
